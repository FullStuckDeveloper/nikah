<a class="media" href="<?php echo $_POST['id']; ?>.pdf"></a>
 
<script type="text/javascript">
    $(function () {
        $('.media').media({width: 868});
    });
</script>