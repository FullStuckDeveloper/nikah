<!doctype html>
<html>
    <head>
        <title>jquery media - harviacode.com</title>
    </head>
    <body>
 
        <a class="media" href="pdf-sample.pdf"></a>
 
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript" src="jquery.media.js"></script>
        <script type="text/javascript">
            $(function () {
                $('.media').media({width: 868, height: 600});
            });
        </script>
    </body>
</html>